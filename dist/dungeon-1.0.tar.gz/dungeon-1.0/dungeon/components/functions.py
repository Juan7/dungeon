"""Contain all the functions used in components."""

def set_field(width, height):
    matrix = [[None for y in range(height)] for x in range(width)]
    return matrix
