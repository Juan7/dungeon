# Dungeon
A small game on pyhton

## Features
Custom size of map.
Custom number of enemies.

## Init config file example:
DEFAULT_WIDTH = 15
DEFAULT_HEIGHT = 8
DEFAULT_ENEMIES = 6

MAX_WIDTH = 20
MAX_HEIGHT = 13
MAX_ENEMIES = 15
LIVES = 3

MOVE_UP = w
MOVE_DOWN = s
MOVE_LEFT = a
MOVE_RIGHT = d
